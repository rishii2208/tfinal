"""Tests for create_app factory function."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from app import create_app


class TestCreateApp:
    """Verify create_app returns a Flask application with routes and seeded data."""

    def test_create_app_returns_flask_instance(self):
        app = create_app("testing")
        assert app is not None

    def test_create_app_has_test_client(self):
        app = create_app("testing")
        client = app.test_client()
        assert client is not None

    def test_create_app_seeds_inventory(self):
        app = create_app("testing")
        client = app.test_client()
        resp = client.get("/api/inventory")
        assert resp.status_code == 200
        assert len(resp.get_json()) == 11

    def test_create_app_registers_recipe_routes(self):
        app = create_app("testing")
        client = app.test_client()
        resp = client.get("/api/recipes")
        assert resp.status_code == 200

    def test_create_app_registers_batch_routes(self):
        app = create_app("testing")
        client = app.test_client()
        resp = client.get("/api/batches")
        assert resp.status_code == 200

    def test_create_app_registers_order_routes(self):
        app = create_app("testing")
        client = app.test_client()
        resp = client.get("/api/orders")
        assert resp.status_code == 200

    def test_create_app_registers_dashboard_route(self):
        app = create_app("testing")
        client = app.test_client()
        resp = client.get("/api/dashboard")
        assert resp.status_code == 200
