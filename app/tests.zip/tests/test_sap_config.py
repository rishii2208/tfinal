"""Tests for SAP_VALUES configuration (sap_config.py)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from sap_config import SAP_VALUES


class TestSAPValues:
    """Verify the SAP reference configuration contains exactly the 10 oils
    with the correct NaOH SAP values as specified in the prompt."""

    def test_sap_values_contains_exactly_10_entries(self):
        assert len(SAP_VALUES) == 10

    def test_sap_values_olive_oil(self):
        assert SAP_VALUES["olive_oil"] == 0.1340

    def test_sap_values_coconut_oil(self):
        assert SAP_VALUES["coconut_oil"] == 0.1780

    def test_sap_values_palm_oil(self):
        assert SAP_VALUES["palm_oil"] == 0.1410

    def test_sap_values_shea_butter(self):
        assert SAP_VALUES["shea_butter"] == 0.1280

    def test_sap_values_castor_oil(self):
        assert SAP_VALUES["castor_oil"] == 0.1286

    def test_sap_values_sweet_almond_oil(self):
        assert SAP_VALUES["sweet_almond_oil"] == 0.1360

    def test_sap_values_avocado_oil(self):
        assert SAP_VALUES["avocado_oil"] == 0.1330

    def test_sap_values_sunflower_oil(self):
        assert SAP_VALUES["sunflower_oil"] == 0.1360

    def test_sap_values_cocoa_butter(self):
        assert SAP_VALUES["cocoa_butter"] == 0.1370

    def test_sap_values_jojoba_oil(self):
        assert SAP_VALUES["jojoba_oil"] == 0.0690
