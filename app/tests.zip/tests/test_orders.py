"""Tests for Order API endpoints."""
import sys, os, math
from datetime import date, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from helpers import stock_inventory, create_recipe, create_batch


def make_ready_batch(client, total_bars_needed=20):
    """Helper to create a Ready batch with enough bars."""
    stock_inventory(client, quantity=50000.0, cost=0.50)
    oils = [
        {"name": "olive_oil", "weight_oz": 30},
        {"name": "coconut_oil", "weight_oz": 20},
    ]
    recipe = create_recipe(client, process="cold_process", oils=oils,
                            superfat=5, water_ratio=2.0).get_json()
    pour = (date.today() - timedelta(days=30)).isoformat()
    batch = create_batch(client, recipe["id"], multiplier=2.0, pour_date=pour).get_json()
    for s in ["Molded", "Unmolded", "Curing", "Ready"]:
        client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
    return batch


class TestCreateOrder:
    """POST /api/orders"""

    def test_create_order_success(self, client):
        batch = make_ready_batch(client)
        items = [
            {"bar_count": 3, "price_per_bar": 6.50},
            {"bar_count": 2, "price_per_bar": 7.00},
        ]
        resp = client.post("/api/orders", json={
            "customer": "Acme Corp",
            "items": items,
        })
        assert resp.status_code == 201
        data = resp.get_json()
        assert "id" in data
        assert data["customer"] == "Acme Corp"
        assert "items" in data
        expected_total = round(3 * 6.50 + 2 * 7.00, 2)
        assert data["total"] == expected_total

    def test_create_order_total_computation(self, client):
        make_ready_batch(client)
        items = [
            {"bar_count": 5, "price_per_bar": 4.25},
        ]
        resp = client.post("/api/orders", json={
            "customer": "Test Co",
            "items": items,
        })
        data = resp.get_json()
        assert data["total"] == round(5 * 4.25, 2)

    def test_create_order_exceeds_available_inventory(self, client):
        batch = make_ready_batch(client)
        # Try to order more bars than available
        huge_count = batch["total_bars"] + 100
        resp = client.post("/api/orders", json={
            "customer": "Greedy Corp",
            "items": [{"bar_count": huge_count, "price_per_bar": 5.00}],
        })
        assert resp.status_code == 400

    def test_create_order_available_inventory_considers_existing_orders(self, client):
        batch = make_ready_batch(client)
        available = batch["total_bars"]
        # Order almost all bars
        first_order_bars = available - 1
        resp1 = client.post("/api/orders", json={
            "customer": "First",
            "items": [{"bar_count": first_order_bars, "price_per_bar": 5.00}],
        })
        assert resp1.status_code == 201

        # Try to order 2 more - only 1 available
        resp2 = client.post("/api/orders", json={
            "customer": "Second",
            "items": [{"bar_count": 2, "price_per_bar": 5.00}],
        })
        assert resp2.status_code == 400

    def test_create_order_no_ready_batches(self, client):
        """No Ready batches means no available inventory."""
        resp = client.post("/api/orders", json={
            "customer": "Nobody",
            "items": [{"bar_count": 1, "price_per_bar": 5.00}],
        })
        assert resp.status_code == 400


class TestGetOrders:
    """GET /api/orders"""

    def test_get_orders_empty(self, client):
        resp = client.get("/api/orders")
        assert resp.status_code == 200
        assert resp.get_json() == []

    def test_get_orders_returns_all(self, client):
        make_ready_batch(client)
        client.post("/api/orders", json={
            "customer": "A",
            "items": [{"bar_count": 1, "price_per_bar": 5.00}],
        })
        client.post("/api/orders", json={
            "customer": "B",
            "items": [{"bar_count": 1, "price_per_bar": 6.00}],
        })
        resp = client.get("/api/orders")
        assert resp.status_code == 200
        assert len(resp.get_json()) == 2

    def test_get_orders_includes_total(self, client):
        make_ready_batch(client)
        client.post("/api/orders", json={
            "customer": "TestCo",
            "items": [{"bar_count": 2, "price_per_bar": 5.50}],
        })
        resp = client.get("/api/orders")
        order = resp.get_json()[0]
        assert "total" in order
        assert order["total"] == round(2 * 5.50, 2)
