"""Tests for calculation functions (calculations.py)."""
import sys, os, math
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from calculations import (
    calculate_lye,
    calculate_adjusted_lye,
    calculate_water,
    calculate_batch_weight,
    calculate_cost_per_bar,
    calculate_wholesale_total,
)
from sap_config import SAP_VALUES


class TestCalculateLye:
    """Verify calculate_lye: sum of (weight_oz * SAP) for all oils, rounded to 2dp."""

    def test_single_oil(self):
        oils = [{"name": "olive_oil", "weight_oz": 10}]
        result = calculate_lye(oils, SAP_VALUES)
        expected = round(10 * 0.1340, 2)
        assert result == expected

    def test_multiple_oils(self):
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
            {"name": "shea_butter", "weight_oz": 3},
        ]
        result = calculate_lye(oils, SAP_VALUES)
        expected = round(10 * 0.1340 + 5 * 0.1780 + 3 * 0.1280, 2)
        assert result == expected

    def test_rounding(self):
        oils = [
            {"name": "castor_oil", "weight_oz": 7.3},
            {"name": "jojoba_oil", "weight_oz": 2.9},
        ]
        result = calculate_lye(oils, SAP_VALUES)
        expected = round(7.3 * 0.1286 + 2.9 * 0.0690, 2)
        assert result == expected


class TestCalculateAdjustedLye:
    """Verify calculate_adjusted_lye: total_lye * (1 - superfat/100), rounded to 2dp."""

    def test_basic(self):
        result = calculate_adjusted_lye(2.72, 5)
        expected = round(2.72 * (1 - 5 / 100), 2)
        assert result == expected

    def test_min_superfat(self):
        result = calculate_adjusted_lye(3.0, 3)
        expected = round(3.0 * (1 - 3 / 100), 2)
        assert result == expected

    def test_max_superfat(self):
        result = calculate_adjusted_lye(3.0, 10)
        expected = round(3.0 * (1 - 10 / 100), 2)
        assert result == expected


class TestCalculateWater:
    """Verify calculate_water: adjusted_lye * water_ratio, rounded to 2dp."""

    def test_basic(self):
        result = calculate_water(2.58, 2.0)
        expected = round(2.58 * 2.0, 2)
        assert result == expected

    def test_custom_ratio(self):
        result = calculate_water(1.5, 2.5)
        expected = round(1.5 * 2.5, 2)
        assert result == expected


class TestCalculateBatchWeight:
    """Verify calculate_batch_weight: (sum_oils + adjusted_lye + water) * multiplier, rounded to 2dp."""

    def test_basic(self):
        oils = [{"weight_oz": 10}, {"weight_oz": 5}]
        result = calculate_batch_weight(oils, 2.58, 5.16, 1.0)
        expected = round((10 + 5 + 2.58 + 5.16) * 1.0, 2)
        assert result == expected

    def test_with_multiplier(self):
        oils = [{"weight_oz": 10}, {"weight_oz": 5}]
        result = calculate_batch_weight(oils, 2.58, 5.16, 2.0)
        expected = round((10 + 5 + 2.58 + 5.16) * 2.0, 2)
        assert result == expected


class TestCalculateCostPerBar:
    """Verify calculate_cost_per_bar: cost / floor(weight/4), rounded to 2dp. 0 when bars=0."""

    def test_basic(self):
        batch_weight = 45.48
        total_bars = math.floor(batch_weight / 4)
        result = calculate_cost_per_bar(18.0, batch_weight)
        expected = round(18.0 / total_bars, 2)
        assert result == expected

    def test_zero_bars_returns_zero(self):
        result = calculate_cost_per_bar(10.0, 3.0)
        assert result == 0.0


class TestCalculateWholesaleTotal:
    """Verify calculate_wholesale_total: sum of (bar_count * price_per_bar), rounded to 2dp."""

    def test_single_item(self):
        items = [{"bar_count": 5, "price_per_bar": 6.50}]
        result = calculate_wholesale_total(items)
        expected = round(5 * 6.50, 2)
        assert result == expected

    def test_multiple_items(self):
        items = [
            {"bar_count": 3, "price_per_bar": 6.50},
            {"bar_count": 2, "price_per_bar": 7.00},
        ]
        result = calculate_wholesale_total(items)
        expected = round(3 * 6.50 + 2 * 7.00, 2)
        assert result == expected
