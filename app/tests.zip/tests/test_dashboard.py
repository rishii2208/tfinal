"""Tests for Dashboard API endpoint - GET /api/dashboard."""
import sys, os, math
from datetime import date, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from helpers import stock_inventory, create_recipe, create_batch


class TestDashboardStructure:
    """GET /api/dashboard returns the six required sections."""

    def test_dashboard_returns_200(self, client):
        resp = client.get("/api/dashboard")
        assert resp.status_code == 200

    def test_dashboard_has_batches_by_stage(self, client):
        data = client.get("/api/dashboard").get_json()
        assert "batches_by_stage" in data
        bbs = data["batches_by_stage"]
        for key in ["Mixed", "Molded", "Unmolded", "Curing", "Ready"]:
            assert key in bbs

    def test_dashboard_has_curing_timeline(self, client):
        data = client.get("/api/dashboard").get_json()
        assert "curing_timeline" in data
        assert isinstance(data["curing_timeline"], list)

    def test_dashboard_has_inventory_levels(self, client):
        data = client.get("/api/dashboard").get_json()
        assert "inventory_levels" in data
        assert isinstance(data["inventory_levels"], list)

    def test_dashboard_has_wholesale_orders(self, client):
        data = client.get("/api/dashboard").get_json()
        assert "wholesale_orders" in data
        assert isinstance(data["wholesale_orders"], list)

    def test_dashboard_has_cost_analysis(self, client):
        data = client.get("/api/dashboard").get_json()
        assert "cost_analysis" in data
        assert isinstance(data["cost_analysis"], list)

    def test_dashboard_has_revenue(self, client):
        data = client.get("/api/dashboard").get_json()
        assert "revenue" in data


class TestDashboardBatchesByStage:
    """batches_by_stage counts batches per status."""

    def test_all_stages_zero_initially(self, client):
        data = client.get("/api/dashboard").get_json()
        bbs = data["batches_by_stage"]
        for key in ["Mixed", "Molded", "Unmolded", "Curing", "Ready"]:
            assert bbs[key] == 0

    def test_counts_mixed_batch(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        create_batch(client, recipe["id"])
        data = client.get("/api/dashboard").get_json()
        assert data["batches_by_stage"]["Mixed"] == 1


class TestDashboardCuringTimeline:
    """curing_timeline contains entries for Curing batches."""

    def test_curing_timeline_entry_fields(self, client):
        stock_inventory(client)
        pour = (date.today() - timedelta(days=10)).isoformat()
        recipe = create_recipe(client, name="Curing Soap", process="cold_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})

        data = client.get("/api/dashboard").get_json()
        timeline = data["curing_timeline"]
        assert len(timeline) == 1
        entry = timeline[0]
        assert "batch_id" in entry
        assert "recipe_name" in entry
        assert "pour_date" in entry
        assert "days_remaining" in entry

    def test_curing_timeline_days_remaining(self, client):
        stock_inventory(client)
        days_ago = 10
        pour = (date.today() - timedelta(days=days_ago)).isoformat()
        recipe = create_recipe(client, process="cold_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})

        data = client.get("/api/dashboard").get_json()
        entry = data["curing_timeline"][0]
        # cold_process requires 28 days; 10 elapsed => 18 remaining
        assert entry["days_remaining"] == 28 - days_ago

    def test_curing_timeline_empty_when_no_curing_batches(self, client):
        data = client.get("/api/dashboard").get_json()
        assert data["curing_timeline"] == []


class TestDashboardInventoryLevels:
    """inventory_levels returns all items with low_stock."""

    def test_inventory_levels_count(self, client):
        data = client.get("/api/dashboard").get_json()
        assert len(data["inventory_levels"]) == 11

    def test_inventory_levels_has_low_stock_flag(self, client):
        data = client.get("/api/dashboard").get_json()
        for item in data["inventory_levels"]:
            assert "low_stock" in item
            assert "name" in item
            assert "quantity_oz" in item
            assert "cost_per_oz" in item


class TestDashboardWholesaleOrders:
    """wholesale_orders returns order summaries."""

    def test_wholesale_order_fields(self, client):
        stock_inventory(client, quantity=50000.0)
        oils = [{"name": "olive_oil", "weight_oz": 30}, {"name": "coconut_oil", "weight_oz": 20}]
        recipe = create_recipe(client, process="cold_process", oils=oils, superfat=5).get_json()
        pour = (date.today() - timedelta(days=30)).isoformat()
        batch = create_batch(client, recipe["id"], multiplier=2.0, pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing", "Ready"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})

        client.post("/api/orders", json={
            "customer": "Dashboard Test",
            "items": [{"bar_count": 2, "price_per_bar": 5.00}],
        })

        data = client.get("/api/dashboard").get_json()
        orders = data["wholesale_orders"]
        assert len(orders) == 1
        o = orders[0]
        assert "id" in o
        assert "customer" in o
        assert "total" in o
        assert "item_count" in o


class TestDashboardCostAnalysis:
    """cost_analysis has avg_cost_per_bar per recipe with batches."""

    def test_cost_analysis_with_batch(self, client):
        stock_inventory(client, cost=0.50)
        oils = [{"name": "olive_oil", "weight_oz": 10}]
        recipe = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0).get_json()
        batch = create_batch(client, recipe["id"], multiplier=1.0).get_json()

        data = client.get("/api/dashboard").get_json()
        ca = data["cost_analysis"]
        assert len(ca) == 1
        assert ca[0]["recipe_name"] == recipe["name"]
        assert ca[0]["avg_cost_per_bar"] == batch["cost_per_bar"]

    def test_cost_analysis_empty_without_batches(self, client):
        create_recipe(client)
        data = client.get("/api/dashboard").get_json()
        assert data["cost_analysis"] == []

    def test_cost_analysis_avg_across_multiple_batches(self, client):
        stock_inventory(client, cost=0.50)
        oils = [{"name": "olive_oil", "weight_oz": 10}]
        recipe = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0).get_json()
        b1 = create_batch(client, recipe["id"], multiplier=1.0).get_json()
        b2 = create_batch(client, recipe["id"], multiplier=2.0).get_json()

        data = client.get("/api/dashboard").get_json()
        ca = data["cost_analysis"]
        assert len(ca) == 1
        expected_avg = round((b1["cost_per_bar"] + b2["cost_per_bar"]) / 2, 2)
        assert ca[0]["avg_cost_per_bar"] == expected_avg


class TestDashboardRevenue:
    """revenue is the sum of all order totals."""

    def test_revenue_zero_with_no_orders(self, client):
        data = client.get("/api/dashboard").get_json()
        assert data["revenue"] == 0

    def test_revenue_sums_all_orders(self, client):
        stock_inventory(client, quantity=50000.0)
        oils = [{"name": "olive_oil", "weight_oz": 30}, {"name": "coconut_oil", "weight_oz": 20}]
        recipe = create_recipe(client, process="cold_process", oils=oils, superfat=5).get_json()
        pour = (date.today() - timedelta(days=30)).isoformat()
        batch = create_batch(client, recipe["id"], multiplier=2.0, pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing", "Ready"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})

        client.post("/api/orders", json={
            "customer": "A",
            "items": [{"bar_count": 2, "price_per_bar": 5.00}],
        })
        client.post("/api/orders", json={
            "customer": "B",
            "items": [{"bar_count": 3, "price_per_bar": 6.00}],
        })

        data = client.get("/api/dashboard").get_json()
        expected = round(2 * 5.00 + 3 * 6.00, 2)
        assert data["revenue"] == expected
