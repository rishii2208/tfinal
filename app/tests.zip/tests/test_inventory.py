"""Tests for Inventory API endpoints."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from sap_config import SAP_VALUES
from helpers import stock_inventory, create_recipe, create_batch


class TestInventorySeeding:
    """Verify inventory is seeded on startup with all 10 SAP oils + sodium_hydroxide."""

    def test_inventory_has_11_items(self, client):
        resp = client.get("/api/inventory")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 11

    def test_inventory_contains_all_sap_oils(self, client):
        resp = client.get("/api/inventory")
        names = {item["name"] for item in resp.get_json()}
        for oil_name in SAP_VALUES:
            assert oil_name in names

    def test_inventory_contains_sodium_hydroxide(self, client):
        resp = client.get("/api/inventory")
        names = {item["name"] for item in resp.get_json()}
        assert "sodium_hydroxide" in names

    def test_inventory_initial_quantity_zero(self, client):
        resp = client.get("/api/inventory")
        for item in resp.get_json():
            assert item["quantity_oz"] == 0

    def test_inventory_initial_cost_zero(self, client):
        resp = client.get("/api/inventory")
        for item in resp.get_json():
            assert item["cost_per_oz"] == 0


class TestGetInventory:
    """GET /api/inventory"""

    def test_get_inventory_includes_low_stock_flag(self, client):
        resp = client.get("/api/inventory")
        data = resp.get_json()
        for item in data:
            assert "low_stock" in item

    def test_get_inventory_item_fields(self, client):
        resp = client.get("/api/inventory")
        item = resp.get_json()[0]
        assert "id" in item
        assert "name" in item
        assert "quantity_oz" in item
        assert "cost_per_oz" in item
        assert "low_stock" in item


class TestUpdateInventory:
    """PUT /api/inventory/<id>"""

    def test_update_inventory_quantity_and_cost(self, client):
        inv = client.get("/api/inventory").get_json()
        item_id = inv[0]["id"]
        resp = client.put(f"/api/inventory/{item_id}", json={
            "quantity_oz": 100.0,
            "cost_per_oz": 0.75,
        })
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["quantity_oz"] == 100.0
        assert data["cost_per_oz"] == 0.75

    def test_update_inventory_not_found(self, client):
        resp = client.put("/api/inventory/9999", json={
            "quantity_oz": 100.0,
            "cost_per_oz": 0.75,
        })
        assert resp.status_code == 404


class TestInventoryDecrement:
    """Inventory is decremented when a batch is created."""

    def test_oil_inventory_decremented_on_batch(self, client):
        stock_inventory(client, quantity=500.0)
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        recipe = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0).get_json()
        create_batch(client, recipe["id"], multiplier=2.0)

        inv = client.get("/api/inventory").get_json()
        olive = next(i for i in inv if i["name"] == "olive_oil")
        coconut = next(i for i in inv if i["name"] == "coconut_oil")
        assert olive["quantity_oz"] == 500.0 - 10 * 2.0
        assert coconut["quantity_oz"] == 500.0 - 5 * 2.0

    def test_sodium_hydroxide_decremented_on_batch(self, client):
        stock_inventory(client, quantity=500.0)
        oils = [{"name": "olive_oil", "weight_oz": 10}]
        recipe = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0).get_json()
        create_batch(client, recipe["id"], multiplier=1.0)

        inv = client.get("/api/inventory").get_json()
        sodium = next(i for i in inv if i["name"] == "sodium_hydroxide")
        assert sodium["quantity_oz"] == 500.0 - recipe["adjusted_lye"] * 1.0

    def test_insufficient_oil_inventory_returns_400(self, client):
        # Leave inventory at 0 - insufficient
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=1.0)
        assert resp.status_code == 400

    def test_insufficient_sodium_hydroxide_returns_400(self, client):
        # Stock only oils, not sodium_hydroxide
        inv = client.get("/api/inventory").get_json()
        for item in inv:
            if item["name"] != "sodium_hydroxide":
                client.put(f"/api/inventory/{item['id']}", json={
                    "quantity_oz": 5000, "cost_per_oz": 0.50
                })
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=1.0)
        assert resp.status_code == 400


class TestLowStockFlag:
    """low_stock is true when quantity_oz < amount needed for a multiplier=1 batch."""

    def test_low_stock_true_when_below_recipe_requirement(self, client):
        oils = [{"name": "olive_oil", "weight_oz": 20}]
        create_recipe(client, oils=oils, superfat=5)
        # Set olive_oil quantity to less than 20
        inv = client.get("/api/inventory").get_json()
        olive = next(i for i in inv if i["name"] == "olive_oil")
        client.put(f"/api/inventory/{olive['id']}", json={
            "quantity_oz": 10, "cost_per_oz": 0.50
        })
        inv2 = client.get("/api/inventory").get_json()
        olive2 = next(i for i in inv2 if i["name"] == "olive_oil")
        assert olive2["low_stock"] is True

    def test_low_stock_false_when_sufficient(self, client):
        oils = [{"name": "olive_oil", "weight_oz": 10}]
        create_recipe(client, oils=oils, superfat=5)
        inv = client.get("/api/inventory").get_json()
        olive = next(i for i in inv if i["name"] == "olive_oil")
        client.put(f"/api/inventory/{olive['id']}", json={
            "quantity_oz": 100, "cost_per_oz": 0.50
        })
        inv2 = client.get("/api/inventory").get_json()
        olive2 = next(i for i in inv2 if i["name"] == "olive_oil")
        assert olive2["low_stock"] is False

    def test_low_stock_for_sodium_hydroxide(self, client):
        oils = [{"name": "olive_oil", "weight_oz": 10}]
        recipe = create_recipe(client, oils=oils, superfat=5).get_json()
        # Set sodium_hydroxide to less than adjusted_lye
        inv = client.get("/api/inventory").get_json()
        sodium = next(i for i in inv if i["name"] == "sodium_hydroxide")
        client.put(f"/api/inventory/{sodium['id']}", json={
            "quantity_oz": recipe["adjusted_lye"] - 0.1,
            "cost_per_oz": 0.50,
        })
        inv2 = client.get("/api/inventory").get_json()
        sodium2 = next(i for i in inv2 if i["name"] == "sodium_hydroxide")
        assert sodium2["low_stock"] is True

    def test_low_stock_false_no_recipes(self, client):
        """With no recipes, no low_stock should be flagged."""
        inv = client.get("/api/inventory").get_json()
        for item in inv:
            assert item["low_stock"] is False
