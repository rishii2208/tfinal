"""Shared test helper functions."""


def stock_inventory(client, quantity=5000.0, cost=0.50):
    """Stock all inventory items."""
    inv = client.get("/api/inventory").get_json()
    for item in inv:
        client.put(f"/api/inventory/{item['id']}", json={
            "quantity_oz": quantity,
            "cost_per_oz": cost,
        })
    return inv


def create_recipe(client, name="Test Soap", process="cold_process",
                  oils=None, superfat=5, water_ratio=2.0):
    """Create a recipe with defaults."""
    if oils is None:
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
    return client.post("/api/recipes", json={
        "name": name,
        "process": process,
        "oils": oils,
        "superfat": superfat,
        "water_ratio": water_ratio,
    })


def create_batch(client, recipe_id, multiplier=1.0, pour_date="2025-01-15"):
    """Create a batch."""
    return client.post("/api/batches", json={
        "recipe_id": recipe_id,
        "multiplier": multiplier,
        "pour_date": pour_date,
    })
