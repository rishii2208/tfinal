"""Tests for Recipe API endpoints."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from helpers import create_recipe


class TestCreateRecipe:
    """POST /api/recipes"""

    def testcreate_recipe_success(self, client):
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        resp = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0)
        assert resp.status_code == 201
        data = resp.get_json()
        assert "id" in data
        assert data["name"] == "Test Soap"
        assert data["process"] == "cold_process"
        assert data["oils"] == oils
        assert data["superfat"] == 5
        assert data["water_ratio"] == 2.0

    def testcreate_recipe_computes_total_lye(self, client):
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        resp = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0)
        data = resp.get_json()
        expected_total_lye = round(10 * 0.1340 + 5 * 0.1780, 2)
        assert data["total_lye"] == expected_total_lye

    def testcreate_recipe_computes_adjusted_lye(self, client):
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        resp = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0)
        data = resp.get_json()
        expected_total_lye = round(10 * 0.1340 + 5 * 0.1780, 2)
        expected_adj = round(expected_total_lye * (1 - 5 / 100), 2)
        assert data["adjusted_lye"] == expected_adj

    def testcreate_recipe_computes_water(self, client):
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        resp = create_recipe(client, oils=oils, superfat=5, water_ratio=2.5)
        data = resp.get_json()
        expected_total_lye = round(10 * 0.1340 + 5 * 0.1780, 2)
        expected_adj = round(expected_total_lye * (1 - 5 / 100), 2)
        expected_water = round(expected_adj * 2.5, 2)
        assert data["water"] == expected_water

    def testcreate_recipe_water_ratio_defaults_to_2(self, client):
        resp = client.post("/api/recipes", json={
            "name": "Default Water",
            "process": "cold_process",
            "oils": [{"name": "olive_oil", "weight_oz": 10}],
            "superfat": 5,
        })
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["water_ratio"] == 2.0
        expected_total_lye = round(10 * 0.1340, 2)
        expected_adj = round(expected_total_lye * (1 - 5 / 100), 2)
        expected_water = round(expected_adj * 2.0, 2)
        assert data["water"] == expected_water

    def testcreate_recipe_invalid_process_type(self, client):
        resp = create_recipe(client, process="unknown_process")
        assert resp.status_code == 400

    def testcreate_recipe_cold_process_valid(self, client):
        resp = create_recipe(client, process="cold_process")
        assert resp.status_code == 201

    def testcreate_recipe_hot_process_valid(self, client):
        resp = create_recipe(client, process="hot_process")
        assert resp.status_code == 201

    def testcreate_recipe_melt_and_pour_valid(self, client):
        resp = create_recipe(client, process="melt_and_pour")
        assert resp.status_code == 201

    def testcreate_recipe_unrecognized_oil_name(self, client):
        resp = create_recipe(client, oils=[{"name": "unknown_oil", "weight_oz": 10}])
        assert resp.status_code == 400

    def testcreate_recipe_zero_weight_oz(self, client):
        resp = create_recipe(client, oils=[{"name": "olive_oil", "weight_oz": 0}])
        assert resp.status_code == 400

    def testcreate_recipe_negative_weight_oz(self, client):
        resp = create_recipe(client, oils=[{"name": "olive_oil", "weight_oz": -5}])
        assert resp.status_code == 400

    def testcreate_recipe_superfat_below_3(self, client):
        resp = create_recipe(client, superfat=2)
        assert resp.status_code == 400

    def testcreate_recipe_superfat_above_10(self, client):
        resp = create_recipe(client, superfat=11)
        assert resp.status_code == 400

    def testcreate_recipe_superfat_at_3(self, client):
        resp = create_recipe(client, superfat=3)
        assert resp.status_code == 201

    def testcreate_recipe_superfat_at_10(self, client):
        resp = create_recipe(client, superfat=10)
        assert resp.status_code == 201

    def testcreate_recipe_water_ratio_below_1_5(self, client):
        resp = create_recipe(client, water_ratio=1.4)
        assert resp.status_code == 400

    def testcreate_recipe_water_ratio_above_3(self, client):
        resp = create_recipe(client, water_ratio=3.1)
        assert resp.status_code == 400

    def testcreate_recipe_water_ratio_at_1_5(self, client):
        resp = create_recipe(client, water_ratio=1.5)
        assert resp.status_code == 201

    def testcreate_recipe_water_ratio_at_3(self, client):
        resp = create_recipe(client, water_ratio=3.0)
        assert resp.status_code == 201


class TestGetRecipes:
    """GET /api/recipes"""

    def test_get_recipes_empty(self, client):
        resp = client.get("/api/recipes")
        assert resp.status_code == 200
        assert resp.get_json() == []

    def test_get_recipes_returns_all(self, client):
        create_recipe(client, name="Soap A")
        create_recipe(client, name="Soap B")
        resp = client.get("/api/recipes")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 2

    def test_get_recipes_includes_computed_fields(self, client):
        create_recipe(client)
        resp = client.get("/api/recipes")
        data = resp.get_json()
        recipe = data[0]
        assert "total_lye" in recipe
        assert "adjusted_lye" in recipe
        assert "water" in recipe


class TestGetRecipeById:
    """GET /api/recipes/<id>"""

    def test_get_recipe_by_id(self, client):
        create_resp = create_recipe(client)
        recipe_id = create_resp.get_json()["id"]
        resp = client.get(f"/api/recipes/{recipe_id}")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["id"] == recipe_id
        assert "total_lye" in data
        assert "adjusted_lye" in data
        assert "water" in data

    def test_get_recipe_not_found(self, client):
        resp = client.get("/api/recipes/9999")
        assert resp.status_code == 404
