"""Tests for Batch API endpoints."""
import sys, os, math
from datetime import date, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from helpers import stock_inventory, create_recipe, create_batch


class TestCreateBatch:
    """POST /api/batches"""

    def testcreate_batch_success(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=1.0)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["recipe_id"] == recipe["id"]
        assert data["multiplier"] == 1.0
        assert data["status"] == "Mixed"

    def testcreate_batch_returns_computed_fields(self, client):
        stock_inventory(client)
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        recipe = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0).get_json()
        resp = create_batch(client, recipe["id"], multiplier=2.0)
        assert resp.status_code == 201
        data = resp.get_json()

        total_oil = 10 + 5
        expected_bw = round((total_oil + recipe["adjusted_lye"] + recipe["water"]) * 2.0, 2)
        expected_bars = math.floor(expected_bw / 4)

        assert data["batch_weight"] == expected_bw
        assert data["total_bars"] == expected_bars
        assert "cost_per_bar" in data

    def testcreate_batch_cost_per_bar_calculation(self, client):
        cost_per_oz = 0.50
        stock_inventory(client, cost=cost_per_oz)
        oils = [
            {"name": "olive_oil", "weight_oz": 10},
            {"name": "coconut_oil", "weight_oz": 5},
        ]
        recipe = create_recipe(client, oils=oils, superfat=5, water_ratio=2.0).get_json()
        multiplier = 2.0
        resp = create_batch(client, recipe["id"], multiplier=multiplier)
        data = resp.get_json()

        oil_cost = (10 + 5) * multiplier * cost_per_oz
        lye_cost = recipe["adjusted_lye"] * multiplier * cost_per_oz
        total_cost = oil_cost + lye_cost

        total_oil = 10 + 5
        bw = round((total_oil + recipe["adjusted_lye"] + recipe["water"]) * multiplier, 2)
        total_bars = math.floor(bw / 4)
        expected_cpb = round(total_cost / total_bars, 2) if total_bars > 0 else 0

        assert data["cost_per_bar"] == expected_cpb

    def testcreate_batch_multiplier_below_0_5(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=0.4)
        assert resp.status_code == 400

    def testcreate_batch_multiplier_above_10(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=11)
        assert resp.status_code == 400

    def testcreate_batch_multiplier_at_0_5(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=0.5)
        assert resp.status_code == 201

    def testcreate_batch_multiplier_at_10(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=10)
        assert resp.status_code == 201

    def testcreate_batch_insufficient_inventory(self, client):
        # Don't stock inventory - quantities are 0
        recipe = create_recipe(client).get_json()
        resp = create_batch(client, recipe["id"], multiplier=1.0)
        assert resp.status_code == 400

    def testcreate_batch_nonexistent_recipe(self, client):
        stock_inventory(client)
        resp = create_batch(client, 9999, multiplier=1.0)
        assert resp.status_code == 400


class TestGetBatches:
    """GET /api/batches"""

    def test_get_batches_empty(self, client):
        resp = client.get("/api/batches")
        assert resp.status_code == 200
        assert resp.get_json() == []

    def test_get_batches_returns_all(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        create_batch(client, recipe["id"])
        create_batch(client, recipe["id"])
        resp = client.get("/api/batches")
        assert resp.status_code == 200
        assert len(resp.get_json()) == 2


class TestGetBatchById:
    """GET /api/batches/<id>"""

    def test_get_batch_by_id(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        resp = client.get(f"/api/batches/{batch['id']}")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["id"] == batch["id"]
        assert "batch_weight" in data
        assert "total_bars" in data
        assert "cost_per_bar" in data
        assert "status" in data

    def test_get_batch_not_found(self, client):
        resp = client.get("/api/batches/9999")
        assert resp.status_code == 404


class TestBatchStatusTransitions:
    """PATCH /api/batches/<id>/status"""

    def test_valid_transition_mixed_to_molded(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Molded"})
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "Molded"

    def test_valid_transition_molded_to_unmolded(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Molded"})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Unmolded"})
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "Unmolded"

    def test_valid_transition_unmolded_to_curing(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        for s in ["Molded", "Unmolded"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Curing"})
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "Curing"

    def test_valid_transition_curing_to_ready_cold_process(self, client):
        stock_inventory(client)
        pour = (date.today() - timedelta(days=30)).isoformat()
        recipe = create_recipe(client, process="cold_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Ready"})
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "Ready"

    def test_skip_stage_returns_400(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        # Skip from Mixed to Unmolded
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Unmolded"})
        assert resp.status_code == 400

    def test_backward_transition_returns_400(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Molded"})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Mixed"})
        assert resp.status_code == 400

    def test_invalid_status_value_returns_400(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "InvalidStatus"})
        assert resp.status_code == 400

    def test_status_update_batch_not_found(self, client):
        resp = client.patch("/api/batches/9999/status", json={"status": "Molded"})
        assert resp.status_code == 404

    def test_cure_time_not_met_cold_process(self, client):
        stock_inventory(client)
        # Pour date only 5 days ago - cold_process needs 28 days
        pour = (date.today() - timedelta(days=5)).isoformat()
        recipe = create_recipe(client, process="cold_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Ready"})
        assert resp.status_code == 400

    def test_cure_time_met_hot_process(self, client):
        stock_inventory(client)
        pour = (date.today() - timedelta(days=8)).isoformat()
        recipe = create_recipe(client, process="hot_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Ready"})
        assert resp.status_code == 200

    def test_cure_time_not_met_hot_process(self, client):
        stock_inventory(client)
        pour = (date.today() - timedelta(days=3)).isoformat()
        recipe = create_recipe(client, process="hot_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Ready"})
        assert resp.status_code == 400

    def test_cure_time_melt_and_pour_immediate(self, client):
        stock_inventory(client)
        pour = date.today().isoformat()
        recipe = create_recipe(client, process="melt_and_pour").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Ready"})
        assert resp.status_code == 200


class TestDeleteBatch:
    """DELETE /api/batches/<id>"""

    def test_delete_mixed_batch(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        resp = client.delete(f"/api/batches/{batch['id']}")
        assert resp.status_code == 200

    def test_delete_molded_batch(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        client.patch(f"/api/batches/{batch['id']}/status", json={"status": "Molded"})
        resp = client.delete(f"/api/batches/{batch['id']}")
        assert resp.status_code == 200

    def test_delete_unmolded_batch(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        for s in ["Molded", "Unmolded"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.delete(f"/api/batches/{batch['id']}")
        assert resp.status_code == 200

    def test_delete_curing_batch_returns_400(self, client):
        stock_inventory(client)
        recipe = create_recipe(client).get_json()
        batch = create_batch(client, recipe["id"]).get_json()
        for s in ["Molded", "Unmolded", "Curing"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.delete(f"/api/batches/{batch['id']}")
        assert resp.status_code == 400

    def test_delete_ready_batch_returns_400(self, client):
        stock_inventory(client)
        pour = (date.today() - timedelta(days=30)).isoformat()
        recipe = create_recipe(client, process="cold_process").get_json()
        batch = create_batch(client, recipe["id"], pour_date=pour).get_json()
        for s in ["Molded", "Unmolded", "Curing", "Ready"]:
            client.patch(f"/api/batches/{batch['id']}/status", json={"status": s})
        resp = client.delete(f"/api/batches/{batch['id']}")
        assert resp.status_code == 400

    def test_delete_batch_not_found(self, client):
        resp = client.delete("/api/batches/9999")
        assert resp.status_code == 404
