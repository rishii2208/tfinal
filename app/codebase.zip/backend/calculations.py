import math


def calculate_lye(oils, sap_values):
    total = sum(oil["weight_oz"] * sap_values[oil["name"]] for oil in oils)
    return round(total, 2)


def calculate_adjusted_lye(total_lye, superfat):
    return round(total_lye * (1 - superfat / 100), 2)


def calculate_water(adjusted_lye, water_ratio):
    return round(adjusted_lye * water_ratio, 2)


def calculate_batch_weight(oils, adjusted_lye, water, multiplier):
    total_oil = sum(oil["weight_oz"] for oil in oils)
    return round((total_oil + adjusted_lye + water) * multiplier, 2)


def calculate_cost_per_bar(total_ingredient_cost, batch_weight):
    total_bars = math.floor(batch_weight / 4)
    if total_bars == 0:
        return 0.0
    return round(total_ingredient_cost / total_bars, 2)


def calculate_wholesale_total(items):
    total = sum(item["bar_count"] * item["price_per_bar"] for item in items)
    return round(total, 2)
