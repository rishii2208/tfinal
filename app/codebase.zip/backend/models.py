from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Recipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    process = db.Column(db.String(50), nullable=False)
    oils = db.Column(db.JSON, nullable=False)
    superfat = db.Column(db.Float, nullable=False)
    water_ratio = db.Column(db.Float, nullable=False, default=2.0)
    total_lye = db.Column(db.Float, nullable=False)
    adjusted_lye = db.Column(db.Float, nullable=False)
    water = db.Column(db.Float, nullable=False)
    batches = db.relationship("Batch", backref="recipe", lazy=True)


class Batch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey("recipe.id"), nullable=False)
    multiplier = db.Column(db.Float, nullable=False)
    pour_date = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Mixed")
    batch_weight = db.Column(db.Float, nullable=False)
    total_bars = db.Column(db.Integer, nullable=False)
    cost_per_bar = db.Column(db.Float, nullable=False)


class InventoryItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    quantity_oz = db.Column(db.Float, nullable=False, default=0)
    cost_per_oz = db.Column(db.Float, nullable=False, default=0)


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer = db.Column(db.String(200), nullable=False)
    items = db.relationship(
        "OrderItem", backref="order", lazy=True, cascade="all, delete-orphan"
    )


class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    bar_count = db.Column(db.Integer, nullable=False)
    price_per_bar = db.Column(db.Float, nullable=False)
