SAP_VALUES = {
    "olive_oil": 0.1340,
    "coconut_oil": 0.1780,
    "palm_oil": 0.1410,
    "shea_butter": 0.1280,
    "castor_oil": 0.1286,
    "sweet_almond_oil": 0.1360,
    "avocado_oil": 0.1330,
    "sunflower_oil": 0.1360,
    "cocoa_butter": 0.1370,
    "jojoba_oil": 0.0690,
}
