import math
import os
import sys
from datetime import date

# Ensure backend directory is on path for reliable module resolution
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, jsonify
from flask_cors import CORS
from models import db, Recipe, Batch, InventoryItem, Order, OrderItem
from sap_config import SAP_VALUES
from calculations import (
    calculate_lye,
    calculate_adjusted_lye,
    calculate_water,
    calculate_batch_weight,
    calculate_cost_per_bar,
    calculate_wholesale_total,
)

VALID_PROCESSES = {"cold_process", "hot_process", "melt_and_pour"}
STATUS_SEQUENCE = ["Mixed", "Molded", "Unmolded", "Curing", "Ready"]
CURE_DAYS = {
    "cold_process": 28,
    "hot_process": 7,
    "melt_and_pour": 0,
}


def compute_low_stock(item, recipes):
    for recipe in recipes:
        if item.name == "sodium_hydroxide":
            if recipe.adjusted_lye > item.quantity_oz:
                return True
        else:
            for oil in recipe.oils:
                if oil["name"] == item.name:
                    if oil["weight_oz"] > item.quantity_oz:
                        return True
    return False


def inventory_to_dict(item, recipes):
    return {
        "id": item.id,
        "name": item.name,
        "quantity_oz": item.quantity_oz,
        "cost_per_oz": item.cost_per_oz,
        "low_stock": compute_low_stock(item, recipes),
    }


def recipe_to_dict(recipe):
    return {
        "id": recipe.id,
        "name": recipe.name,
        "process": recipe.process,
        "oils": recipe.oils,
        "superfat": recipe.superfat,
        "water_ratio": recipe.water_ratio,
        "total_lye": recipe.total_lye,
        "adjusted_lye": recipe.adjusted_lye,
        "water": recipe.water,
    }


def batch_to_dict(batch):
    return {
        "id": batch.id,
        "recipe_id": batch.recipe_id,
        "multiplier": batch.multiplier,
        "pour_date": batch.pour_date,
        "status": batch.status,
        "batch_weight": batch.batch_weight,
        "total_bars": batch.total_bars,
        "cost_per_bar": batch.cost_per_bar,
    }


def order_to_dict(order):
    items = [
        {"bar_count": item.bar_count, "price_per_bar": item.price_per_bar}
        for item in order.items
    ]
    total = calculate_wholesale_total(items)
    return {
        "id": order.id,
        "customer": order.customer,
        "items": items,
        "total": total,
    }


def seed_inventory():
    all_names = list(SAP_VALUES.keys()) + ["sodium_hydroxide"]
    for name in all_names:
        existing = InventoryItem.query.filter_by(name=name).first()
        if not existing:
            item = InventoryItem(name=name, quantity_oz=0, cost_per_oz=0)
            db.session.add(item)
    db.session.commit()


def create_app(config_name="default"):
    app = Flask(__name__)
    CORS(app)

    if config_name == "testing":
        app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app.config["TESTING"] = True
    else:
        app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///soap.db"

    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    with app.app_context():
        db.create_all()
        seed_inventory()

    # ── Recipe endpoints ──────────────────────────────────────────────

    @app.route("/api/recipes", methods=["POST"])
    def create_recipe():
        data = request.get_json()

        name = data.get("name")
        if not name:
            return jsonify({"error": "Recipe name is required"}), 400

        process = data.get("process")
        if process not in VALID_PROCESSES:
            return jsonify({"error": "Invalid process type"}), 400

        oils = data.get("oils", [])
        if not oils:
            return jsonify({"error": "At least one oil is required"}), 400

        for oil in oils:
            if oil.get("name") not in SAP_VALUES:
                return jsonify({"error": f"Unknown oil: {oil.get('name')}"}), 400
            weight = oil.get("weight_oz")
            if not isinstance(weight, (int, float)) or weight <= 0:
                return jsonify({"error": "Oil weight_oz must be a positive number"}), 400

        superfat = data.get("superfat")
        if superfat is None or not isinstance(superfat, (int, float)):
            return jsonify({"error": "Superfat is required"}), 400
        if superfat < 3 or superfat > 10:
            return jsonify({"error": "Superfat must be between 3 and 10"}), 400

        water_ratio = data.get("water_ratio", 2.0)
        if not isinstance(water_ratio, (int, float)):
            return jsonify({"error": "Water ratio must be a number"}), 400
        if water_ratio < 1.5 or water_ratio > 3.0:
            return jsonify({"error": "Water ratio must be between 1.5 and 3.0"}), 400

        total_lye = calculate_lye(oils, SAP_VALUES)
        adjusted_lye = calculate_adjusted_lye(total_lye, superfat)
        water = calculate_water(adjusted_lye, water_ratio)

        recipe = Recipe(
            name=name,
            process=process,
            oils=oils,
            superfat=superfat,
            water_ratio=water_ratio,
            total_lye=total_lye,
            adjusted_lye=adjusted_lye,
            water=water,
        )
        db.session.add(recipe)
        db.session.commit()

        return jsonify(recipe_to_dict(recipe)), 201

    @app.route("/api/recipes", methods=["GET"])
    def get_recipes():
        recipes = Recipe.query.all()
        return jsonify([recipe_to_dict(r) for r in recipes]), 200

    @app.route("/api/recipes/<int:id>", methods=["GET"])
    def get_recipe(id):
        recipe = Recipe.query.get(id)
        if not recipe:
            return jsonify({"error": "Recipe not found"}), 404
        return jsonify(recipe_to_dict(recipe)), 200

    # ── Batch endpoints ───────────────────────────────────────────────

    @app.route("/api/batches", methods=["POST"])
    def create_batch():
        data = request.get_json()

        recipe_id = data.get("recipe_id")
        recipe = Recipe.query.get(recipe_id) if recipe_id else None
        if not recipe:
            return jsonify({"error": "Recipe not found"}), 400

        multiplier = data.get("multiplier")
        if multiplier is None or not isinstance(multiplier, (int, float)):
            return jsonify({"error": "Multiplier is required"}), 400
        if multiplier < 0.5 or multiplier > 10:
            return jsonify({"error": "Multiplier must be between 0.5 and 10"}), 400

        pour_date = data.get("pour_date")
        if not pour_date:
            return jsonify({"error": "pour_date is required"}), 400

        # Check inventory sufficiency for each oil
        for oil in recipe.oils:
            inv_item = InventoryItem.query.filter_by(name=oil["name"]).first()
            required = oil["weight_oz"] * multiplier
            if not inv_item or inv_item.quantity_oz < required:
                return (
                    jsonify({"error": f"Insufficient inventory for {oil['name']}"}),
                    400,
                )

        # Check sodium_hydroxide inventory
        lye_needed = recipe.adjusted_lye * multiplier
        sodium = InventoryItem.query.filter_by(name="sodium_hydroxide").first()
        if not sodium or sodium.quantity_oz < lye_needed:
            return (
                jsonify({"error": "Insufficient inventory for sodium_hydroxide"}),
                400,
            )

        # Calculate cost BEFORE decrementing (cost_per_oz won't change)
        total_ingredient_cost = 0.0
        for oil in recipe.oils:
            inv_item = InventoryItem.query.filter_by(name=oil["name"]).first()
            total_ingredient_cost += oil["weight_oz"] * multiplier * inv_item.cost_per_oz
        total_ingredient_cost += recipe.adjusted_lye * multiplier * sodium.cost_per_oz

        # Decrement inventory
        for oil in recipe.oils:
            inv_item = InventoryItem.query.filter_by(name=oil["name"]).first()
            inv_item.quantity_oz -= oil["weight_oz"] * multiplier
        sodium.quantity_oz -= lye_needed

        # Calculate batch fields
        batch_weight = calculate_batch_weight(
            recipe.oils, recipe.adjusted_lye, recipe.water, multiplier
        )
        total_bars = math.floor(batch_weight / 4)
        cost_per_bar = calculate_cost_per_bar(total_ingredient_cost, batch_weight)

        batch = Batch(
            recipe_id=recipe_id,
            multiplier=multiplier,
            pour_date=pour_date,
            status="Mixed",
            batch_weight=batch_weight,
            total_bars=total_bars,
            cost_per_bar=cost_per_bar,
        )
        db.session.add(batch)
        db.session.commit()

        return jsonify(batch_to_dict(batch)), 201

    @app.route("/api/batches", methods=["GET"])
    def get_batches():
        batches = Batch.query.all()
        return jsonify([batch_to_dict(b) for b in batches]), 200

    @app.route("/api/batches/<int:id>", methods=["GET"])
    def get_batch(id):
        batch = Batch.query.get(id)
        if not batch:
            return jsonify({"error": "Batch not found"}), 404
        return jsonify(batch_to_dict(batch)), 200

    @app.route("/api/batches/<int:id>/status", methods=["PATCH"])
    def update_batch_status(id):
        batch = Batch.query.get(id)
        if not batch:
            return jsonify({"error": "Batch not found"}), 404

        data = request.get_json()
        new_status = data.get("status")

        if new_status not in STATUS_SEQUENCE:
            return jsonify({"error": "Invalid status value"}), 400

        current_index = STATUS_SEQUENCE.index(batch.status)
        new_index = STATUS_SEQUENCE.index(new_status)

        if new_index != current_index + 1:
            return jsonify({"error": "Invalid status transition"}), 400

        # Cure time enforcement for Ready transition
        if new_status == "Ready":
            recipe = Recipe.query.get(batch.recipe_id)
            required_days = CURE_DAYS[recipe.process]
            pour = date.fromisoformat(batch.pour_date)
            elapsed = (date.today() - pour).days
            if elapsed < required_days:
                return (
                    jsonify(
                        {
                            "error": f"Cure time not met. {required_days - elapsed} days remaining"
                        }
                    ),
                    400,
                )

        batch.status = new_status
        db.session.commit()

        return jsonify(batch_to_dict(batch)), 200

    @app.route("/api/batches/<int:id>", methods=["DELETE"])
    def delete_batch(id):
        batch = Batch.query.get(id)
        if not batch:
            return jsonify({"error": "Batch not found"}), 404

        if batch.status in ("Curing", "Ready"):
            return (
                jsonify(
                    {"error": "Cannot delete batch in Curing or Ready status"}
                ),
                400,
            )

        db.session.delete(batch)
        db.session.commit()

        return jsonify({"message": "Batch deleted"}), 200

    # ── Order endpoints ───────────────────────────────────────────────

    @app.route("/api/orders", methods=["POST"])
    def create_order():
        data = request.get_json()

        customer = data.get("customer")
        if not customer:
            return jsonify({"error": "Customer name is required"}), 400

        items = data.get("items", [])
        if not items:
            return jsonify({"error": "At least one item is required"}), 400

        for item in items:
            if (
                not isinstance(item.get("bar_count"), int)
                or item["bar_count"] <= 0
            ):
                return jsonify({"error": "bar_count must be a positive integer"}), 400
            if (
                not isinstance(item.get("price_per_bar"), (int, float))
                or item["price_per_bar"] <= 0
            ):
                return (
                    jsonify({"error": "price_per_bar must be a positive number"}),
                    400,
                )

        total_requested = sum(item["bar_count"] for item in items)

        # Available bar inventory
        ready_batches = Batch.query.filter_by(status="Ready").all()
        total_ready_bars = sum(b.total_bars for b in ready_batches)
        existing_ordered = (
            db.session.query(db.func.coalesce(db.func.sum(OrderItem.bar_count), 0)).scalar()
        )
        available = total_ready_bars - existing_ordered

        if total_requested > available:
            return jsonify({"error": "Insufficient bar inventory"}), 400

        order = Order(customer=customer)
        db.session.add(order)
        db.session.flush()

        for item_data in items:
            order_item = OrderItem(
                order_id=order.id,
                bar_count=item_data["bar_count"],
                price_per_bar=item_data["price_per_bar"],
            )
            db.session.add(order_item)

        db.session.commit()

        return jsonify(order_to_dict(order)), 201

    @app.route("/api/orders", methods=["GET"])
    def get_orders():
        orders = Order.query.all()
        return jsonify([order_to_dict(o) for o in orders]), 200

    # ── Inventory endpoints ───────────────────────────────────────────

    @app.route("/api/inventory", methods=["GET"])
    def get_inventory():
        items = InventoryItem.query.all()
        recipes = Recipe.query.all()
        return jsonify([inventory_to_dict(item, recipes) for item in items]), 200

    @app.route("/api/inventory/<int:id>", methods=["PUT"])
    def update_inventory(id):
        item = InventoryItem.query.get(id)
        if not item:
            return jsonify({"error": "Inventory item not found"}), 404

        data = request.get_json()
        if "quantity_oz" in data:
            item.quantity_oz = data["quantity_oz"]
        if "cost_per_oz" in data:
            item.cost_per_oz = data["cost_per_oz"]
        db.session.commit()

        recipes = Recipe.query.all()
        return jsonify(inventory_to_dict(item, recipes)), 200

    # ── Dashboard endpoint ────────────────────────────────────────────

    @app.route("/api/dashboard", methods=["GET"])
    def get_dashboard():
        # 1. batches_by_stage
        batches_by_stage = {}
        for status in STATUS_SEQUENCE:
            batches_by_stage[status] = Batch.query.filter_by(status=status).count()

        # 2. curing_timeline
        curing_batches = Batch.query.filter_by(status="Curing").all()
        curing_timeline = []
        for batch in curing_batches:
            recipe = Recipe.query.get(batch.recipe_id)
            required_days = CURE_DAYS[recipe.process]
            pour = date.fromisoformat(batch.pour_date)
            elapsed = (date.today() - pour).days
            days_remaining = max(0, required_days - elapsed)
            curing_timeline.append(
                {
                    "batch_id": batch.id,
                    "recipe_name": recipe.name,
                    "pour_date": batch.pour_date,
                    "days_remaining": days_remaining,
                }
            )

        # 3. inventory_levels
        inv_items = InventoryItem.query.all()
        recipes = Recipe.query.all()
        inventory_levels = [inventory_to_dict(item, recipes) for item in inv_items]

        # 4. wholesale_orders
        orders = Order.query.all()
        wholesale_orders = []
        for order in orders:
            items_data = [
                {"bar_count": item.bar_count, "price_per_bar": item.price_per_bar}
                for item in order.items
            ]
            total = calculate_wholesale_total(items_data)
            wholesale_orders.append(
                {
                    "id": order.id,
                    "customer": order.customer,
                    "total": total,
                    "item_count": len(order.items),
                }
            )

        # 5. cost_analysis
        cost_analysis = []
        recipes_with_batches = (
            db.session.query(Recipe).join(Batch).distinct().all()
        )
        for recipe in recipes_with_batches:
            batches = Batch.query.filter_by(recipe_id=recipe.id).all()
            if batches:
                avg_cost = round(
                    sum(b.cost_per_bar for b in batches) / len(batches), 2
                )
                cost_analysis.append(
                    {
                        "recipe_name": recipe.name,
                        "avg_cost_per_bar": avg_cost,
                    }
                )

        # 6. revenue
        all_orders = Order.query.all()
        revenue = 0.0
        for order in all_orders:
            items_data = [
                {"bar_count": item.bar_count, "price_per_bar": item.price_per_bar}
                for item in order.items
            ]
            revenue += calculate_wholesale_total(items_data)
        revenue = round(revenue, 2)

        return (
            jsonify(
                {
                    "batches_by_stage": batches_by_stage,
                    "curing_timeline": curing_timeline,
                    "inventory_levels": inventory_levels,
                    "wholesale_orders": wholesale_orders,
                    "cost_analysis": cost_analysis,
                    "revenue": revenue,
                }
            ),
            200,
        )

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5000)
