import React from "react";
import { BrowserRouter as Router, Routes, Route, NavLink } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import RecipeForm from "./components/RecipeForm";
import BatchList from "./components/BatchList";
import InventoryTable from "./components/InventoryTable";
import OrderForm from "./components/OrderForm";
import "./App.css";

function App() {
  return (
    <Router>
      <div className="app">
        <nav className="navbar">
          <h1>Soap Production Manager</h1>
          <div className="nav-links">
            <NavLink to="/">Dashboard</NavLink>
            <NavLink to="/recipes">Recipes</NavLink>
            <NavLink to="/batches">Batches</NavLink>
            <NavLink to="/inventory">Inventory</NavLink>
            <NavLink to="/orders">Orders</NavLink>
          </div>
        </nav>
        <main className="content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/recipes" element={<RecipeForm />} />
            <Route path="/batches" element={<BatchList />} />
            <Route path="/inventory" element={<InventoryTable />} />
            <Route path="/orders" element={<OrderForm />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
