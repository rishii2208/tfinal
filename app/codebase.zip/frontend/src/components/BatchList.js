import React, { useState, useEffect } from "react";

const STATUS_SEQUENCE = ["Mixed", "Molded", "Unmolded", "Curing", "Ready"];

function BatchList() {
  const [batches, setBatches] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [recipeId, setRecipeId] = useState("");
  const [multiplier, setMultiplier] = useState("1");
  const [pourDate, setPourDate] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const loadBatches = () => {
    fetch("/api/batches")
      .then((res) => res.json())
      .then(setBatches)
      .catch(() => {});
  };

  const loadRecipes = () => {
    fetch("/api/recipes")
      .then((res) => res.json())
      .then(setRecipes)
      .catch(() => {});
  };

  useEffect(() => {
    loadBatches();
    loadRecipes();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const payload = {
      recipe_id: parseInt(recipeId),
      multiplier: parseFloat(multiplier),
      pour_date: pourDate,
    };

    try {
      const res = await fetch("/api/batches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to create batch");
        return;
      }
      setSuccess(`Batch #${data.id} created!`);
      setRecipeId("");
      setMultiplier("1");
      setPourDate("");
      loadBatches();
    } catch {
      setError("Network error");
    }
  };

  const advanceStatus = async (batchId, currentStatus) => {
    const currentIdx = STATUS_SEQUENCE.indexOf(currentStatus);
    if (currentIdx >= STATUS_SEQUENCE.length - 1) return;

    const nextStatus = STATUS_SEQUENCE[currentIdx + 1];

    try {
      const res = await fetch(`/api/batches/${batchId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to update status");
        return;
      }
      setError("");
      loadBatches();
    } catch {
      setError("Network error");
    }
  };

  const deleteBatch = async (batchId) => {
    try {
      const res = await fetch(`/api/batches/${batchId}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to delete batch");
        return;
      }
      setError("");
      loadBatches();
    } catch {
      setError("Network error");
    }
  };

  const getRecipeName = (recipeId) => {
    const r = recipes.find((rec) => rec.id === recipeId);
    return r ? r.name : `Recipe #${recipeId}`;
  };

  const statusBadge = (status) => {
    const cls = `badge badge-${status.toLowerCase()}`;
    return <span className={cls}>{status}</span>;
  };

  return (
    <div>
      <div className="card">
        <h2>Create Batch</h2>
        {error && <div className="error">{error}</div>}
        {success && <div style={{ background: "#e8f8f0", color: "#27ae60", padding: "0.75rem", borderRadius: "4px", marginBottom: "1rem" }}>{success}</div>}

        <form onSubmit={handleCreate}>
          <div className="form-group">
            <label>Recipe</label>
            <select value={recipeId} onChange={(e) => setRecipeId(e.target.value)} required>
              <option value="">-- Select Recipe --</option>
              {recipes.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Multiplier</label>
            <input type="number" step="0.1" min="0.5" max="10" value={multiplier} onChange={(e) => setMultiplier(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Pour Date</label>
            <input type="date" value={pourDate} onChange={(e) => setPourDate(e.target.value)} required />
          </div>

          <button type="submit" className="btn btn-success">Create Batch</button>
        </form>
      </div>

      <div className="card">
        <h2>All Batches</h2>
        {batches.length === 0 ? (
          <p>No batches yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Recipe</th>
                <th>Multiplier</th>
                <th>Pour Date</th>
                <th>Status</th>
                <th>Weight</th>
                <th>Total Bars</th>
                <th>Cost/Bar</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {batches.map((b) => (
                <tr key={b.id}>
                  <td>{b.id}</td>
                  <td>{getRecipeName(b.recipe_id)}</td>
                  <td>{b.multiplier}</td>
                  <td>{b.pour_date}</td>
                  <td>{statusBadge(b.status)}</td>
                  <td>{b.batch_weight} oz</td>
                  <td>{b.total_bars}</td>
                  <td>${b.cost_per_bar.toFixed(2)}</td>
                  <td>
                    {b.status !== "Ready" && (
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => advanceStatus(b.id, b.status)}
                        style={{ marginRight: "0.25rem" }}
                      >
                        Advance
                      </button>
                    )}
                    {!["Curing", "Ready"].includes(b.status) && (
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => deleteBatch(b.id)}
                      >
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default BatchList;
