import React, { useState, useEffect } from "react";

const API = "/api/dashboard";

function Dashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(API)
      .then((res) => res.json())
      .then(setData)
      .catch(() => setError("Failed to load dashboard data"));
  }, []);

  if (error) return <div className="error">{error}</div>;
  if (!data) return <p>Loading...</p>;

  const stageColors = {
    Mixed: "#f1c40f",
    Molded: "#e67e22",
    Unmolded: "#9b59b6",
    Curing: "#3498db",
    Ready: "#27ae60",
  };

  return (
    <div>
      <h2 style={{ marginBottom: "1.5rem", color: "#2c3e50" }}>Dashboard</h2>

      <div className="dashboard-grid">
        {/* Batches by Stage */}
        <div className="card">
          <h3>Batches by Stage</h3>
          <div className="stage-counts">
            {Object.entries(data.batches_by_stage).map(([stage, count]) => (
              <div
                key={stage}
                className="stage-count"
                style={{ background: stageColors[stage], color: stage === "Mixed" ? "#333" : "white" }}
              >
                <div className="count">{count}</div>
                <div className="label">{stage}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue */}
        <div className="card">
          <h3>Revenue</h3>
          <div className="revenue-display">${data.revenue.toFixed(2)}</div>
        </div>

        {/* Curing Timeline */}
        <div className="card">
          <h3>Curing Timeline</h3>
          {data.curing_timeline.length === 0 ? (
            <p>No batches currently curing.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Batch ID</th>
                  <th>Recipe</th>
                  <th>Pour Date</th>
                  <th>Days Remaining</th>
                </tr>
              </thead>
              <tbody>
                {data.curing_timeline.map((item) => (
                  <tr key={item.batch_id}>
                    <td>{item.batch_id}</td>
                    <td>{item.recipe_name}</td>
                    <td>{item.pour_date}</td>
                    <td>{item.days_remaining}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Inventory Levels */}
        <div className="card">
          <h3>Inventory Levels</h3>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Qty (oz)</th>
                <th>Cost/oz</th>
                <th>Low Stock</th>
              </tr>
            </thead>
            <tbody>
              {data.inventory_levels.map((item) => (
                <tr key={item.name} className={item.low_stock ? "low-stock" : ""}>
                  <td>{item.name}</td>
                  <td>{item.quantity_oz}</td>
                  <td>${item.cost_per_oz.toFixed(2)}</td>
                  <td>{item.low_stock ? "⚠ Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Wholesale Orders */}
        <div className="card">
          <h3>Wholesale Orders</h3>
          {data.wholesale_orders.length === 0 ? (
            <p>No orders yet.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Customer</th>
                  <th>Total</th>
                  <th>Items</th>
                </tr>
              </thead>
              <tbody>
                {data.wholesale_orders.map((order) => (
                  <tr key={order.id}>
                    <td>{order.id}</td>
                    <td>{order.customer}</td>
                    <td>${order.total.toFixed(2)}</td>
                    <td>{order.item_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Cost Analysis */}
        <div className="card">
          <h3>Cost Analysis</h3>
          {data.cost_analysis.length === 0 ? (
            <p>No cost data available.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Recipe</th>
                  <th>Avg Cost/Bar</th>
                </tr>
              </thead>
              <tbody>
                {data.cost_analysis.map((item) => (
                  <tr key={item.recipe_name}>
                    <td>{item.recipe_name}</td>
                    <td>${item.avg_cost_per_bar.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
