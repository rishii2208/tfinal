import React, { useState, useEffect } from "react";

const OIL_OPTIONS = [
  "olive_oil", "coconut_oil", "palm_oil", "shea_butter", "castor_oil",
  "sweet_almond_oil", "avocado_oil", "sunflower_oil", "cocoa_butter", "jojoba_oil",
];

const PROCESS_OPTIONS = ["cold_process", "hot_process", "melt_and_pour"];

function RecipeForm() {
  const [recipes, setRecipes] = useState([]);
  const [name, setName] = useState("");
  const [process, setProcess] = useState("cold_process");
  const [oils, setOils] = useState([{ name: "olive_oil", weight_oz: "" }]);
  const [superfat, setSuperfat] = useState("5");
  const [waterRatio, setWaterRatio] = useState("2.0");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const loadRecipes = () => {
    fetch("/api/recipes")
      .then((res) => res.json())
      .then(setRecipes)
      .catch(() => {});
  };

  useEffect(() => { loadRecipes(); }, []);

  const addOil = () => {
    setOils([...oils, { name: "olive_oil", weight_oz: "" }]);
  };

  const removeOil = (index) => {
    setOils(oils.filter((_, i) => i !== index));
  };

  const updateOil = (index, field, value) => {
    const updated = [...oils];
    updated[index] = { ...updated[index], [field]: value };
    setOils(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const payload = {
      name,
      process,
      oils: oils.map((o) => ({ name: o.name, weight_oz: parseFloat(o.weight_oz) })),
      superfat: parseFloat(superfat),
      water_ratio: parseFloat(waterRatio),
    };

    try {
      const res = await fetch("/api/recipes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to create recipe");
        return;
      }
      setSuccess(`Recipe "${data.name}" created! Lye: ${data.total_lye} oz, Adjusted Lye: ${data.adjusted_lye} oz, Water: ${data.water} oz`);
      setName("");
      setOils([{ name: "olive_oil", weight_oz: "" }]);
      setSuperfat("5");
      setWaterRatio("2.0");
      loadRecipes();
    } catch {
      setError("Network error");
    }
  };

  return (
    <div>
      <div className="card">
        <h2>Create Recipe</h2>
        {error && <div className="error">{error}</div>}
        {success && <div style={{ background: "#e8f8f0", color: "#27ae60", padding: "0.75rem", borderRadius: "4px", marginBottom: "1rem" }}>{success}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Recipe Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Process Type</label>
            <select value={process} onChange={(e) => setProcess(e.target.value)}>
              {PROCESS_OPTIONS.map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Oils</label>
            {oils.map((oil, i) => (
              <div key={i} className="oil-row">
                <div className="form-group">
                  <select value={oil.name} onChange={(e) => updateOil(i, "name", e.target.value)}>
                    {OIL_OPTIONS.map((o) => (
                      <option key={o} value={o}>{o}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="Weight (oz)"
                    value={oil.weight_oz}
                    onChange={(e) => updateOil(i, "weight_oz", e.target.value)}
                    required
                  />
                </div>
                {oils.length > 1 && (
                  <button type="button" className="btn btn-danger btn-sm" onClick={() => removeOil(i)}>
                    Remove
                  </button>
                )}
              </div>
            ))}
            <button type="button" className="btn btn-primary btn-sm" onClick={addOil} style={{ marginTop: "0.5rem" }}>
              + Add Oil
            </button>
          </div>

          <div className="form-group">
            <label>Superfat (%)</label>
            <input type="number" step="0.1" min="3" max="10" value={superfat} onChange={(e) => setSuperfat(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Water Ratio</label>
            <input type="number" step="0.1" min="1.5" max="3.0" value={waterRatio} onChange={(e) => setWaterRatio(e.target.value)} required />
          </div>

          <button type="submit" className="btn btn-success">Create Recipe</button>
        </form>
      </div>

      <div className="card">
        <h2>Existing Recipes</h2>
        {recipes.length === 0 ? (
          <p>No recipes yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Process</th>
                <th>Superfat</th>
                <th>Water Ratio</th>
                <th>Total Lye</th>
                <th>Adjusted Lye</th>
                <th>Water</th>
              </tr>
            </thead>
            <tbody>
              {recipes.map((r) => (
                <tr key={r.id}>
                  <td>{r.id}</td>
                  <td>{r.name}</td>
                  <td>{r.process}</td>
                  <td>{r.superfat}%</td>
                  <td>{r.water_ratio}</td>
                  <td>{r.total_lye} oz</td>
                  <td>{r.adjusted_lye} oz</td>
                  <td>{r.water} oz</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default RecipeForm;
