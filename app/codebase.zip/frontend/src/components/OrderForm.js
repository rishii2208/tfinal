import React, { useState, useEffect } from "react";

function OrderForm() {
  const [orders, setOrders] = useState([]);
  const [customer, setCustomer] = useState("");
  const [items, setItems] = useState([{ bar_count: "", price_per_bar: "" }]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const loadOrders = () => {
    fetch("/api/orders")
      .then((res) => res.json())
      .then(setOrders)
      .catch(() => {});
  };

  useEffect(() => { loadOrders(); }, []);

  const addItem = () => {
    setItems([...items, { bar_count: "", price_per_bar: "" }]);
  };

  const removeItem = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const updateItem = (index, field, value) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [field]: value };
    setItems(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const payload = {
      customer,
      items: items.map((item) => ({
        bar_count: parseInt(item.bar_count),
        price_per_bar: parseFloat(item.price_per_bar),
      })),
    };

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to create order");
        return;
      }
      setSuccess(`Order #${data.id} created for ${data.customer}! Total: $${data.total.toFixed(2)}`);
      setCustomer("");
      setItems([{ bar_count: "", price_per_bar: "" }]);
      loadOrders();
    } catch {
      setError("Network error");
    }
  };

  return (
    <div>
      <div className="card">
        <h2>Create Wholesale Order</h2>
        {error && <div className="error">{error}</div>}
        {success && <div style={{ background: "#e8f8f0", color: "#27ae60", padding: "0.75rem", borderRadius: "4px", marginBottom: "1rem" }}>{success}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Customer Name</label>
            <input value={customer} onChange={(e) => setCustomer(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Order Items</label>
            {items.map((item, i) => (
              <div key={i} className="oil-row">
                <div className="form-group">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    placeholder="Bar Count"
                    value={item.bar_count}
                    onChange={(e) => updateItem(i, "bar_count", e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    placeholder="Price per Bar"
                    value={item.price_per_bar}
                    onChange={(e) => updateItem(i, "price_per_bar", e.target.value)}
                    required
                  />
                </div>
                {items.length > 1 && (
                  <button type="button" className="btn btn-danger btn-sm" onClick={() => removeItem(i)}>
                    Remove
                  </button>
                )}
              </div>
            ))}
            <button type="button" className="btn btn-primary btn-sm" onClick={addItem} style={{ marginTop: "0.5rem" }}>
              + Add Item
            </button>
          </div>

          <button type="submit" className="btn btn-success">Create Order</button>
        </form>
      </div>

      <div className="card">
        <h2>Existing Orders</h2>
        {orders.length === 0 ? (
          <p>No orders yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Items</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.customer}</td>
                  <td>
                    {order.items.map((item, i) => (
                      <div key={i}>
                        {item.bar_count} bars @ ${item.price_per_bar.toFixed(2)}
                      </div>
                    ))}
                  </td>
                  <td>${order.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default OrderForm;
