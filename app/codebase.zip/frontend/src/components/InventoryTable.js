import React, { useState, useEffect } from "react";

function InventoryTable() {
  const [items, setItems] = useState([]);
  const [editing, setEditing] = useState(null);
  const [editQty, setEditQty] = useState("");
  const [editCost, setEditCost] = useState("");
  const [error, setError] = useState("");

  const loadInventory = () => {
    fetch("/api/inventory")
      .then((res) => res.json())
      .then(setItems)
      .catch(() => setError("Failed to load inventory"));
  };

  useEffect(() => { loadInventory(); }, []);

  const startEdit = (item) => {
    setEditing(item.id);
    setEditQty(String(item.quantity_oz));
    setEditCost(String(item.cost_per_oz));
    setError("");
  };

  const cancelEdit = () => {
    setEditing(null);
    setEditQty("");
    setEditCost("");
  };

  const saveEdit = async (id) => {
    try {
      const res = await fetch(`/api/inventory/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quantity_oz: parseFloat(editQty),
          cost_per_oz: parseFloat(editCost),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to update");
        return;
      }
      setEditing(null);
      loadInventory();
    } catch {
      setError("Network error");
    }
  };

  return (
    <div className="card">
      <h2>Inventory</h2>
      {error && <div className="error">{error}</div>}

      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Quantity (oz)</th>
            <th>Cost per oz</th>
            <th>Low Stock</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id} className={item.low_stock ? "low-stock" : ""}>
              <td>{item.name}</td>
              <td>
                {editing === item.id ? (
                  <input
                    className="inline-edit"
                    type="number"
                    step="0.01"
                    value={editQty}
                    onChange={(e) => setEditQty(e.target.value)}
                    style={{ width: "80px" }}
                  />
                ) : (
                  item.quantity_oz
                )}
              </td>
              <td>
                {editing === item.id ? (
                  <input
                    className="inline-edit"
                    type="number"
                    step="0.01"
                    value={editCost}
                    onChange={(e) => setEditCost(e.target.value)}
                    style={{ width: "80px" }}
                  />
                ) : (
                  `$${item.cost_per_oz.toFixed(2)}`
                )}
              </td>
              <td>{item.low_stock ? "⚠ Yes" : "No"}</td>
              <td>
                {editing === item.id ? (
                  <>
                    <button className="btn btn-success btn-sm" onClick={() => saveEdit(item.id)} style={{ marginRight: "0.25rem" }}>
                      Save
                    </button>
                    <button className="btn btn-danger btn-sm" onClick={cancelEdit}>
                      Cancel
                    </button>
                  </>
                ) : (
                  <button className="btn btn-primary btn-sm" onClick={() => startEdit(item)}>
                    Edit
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default InventoryTable;
